<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Localidades extends Model
{
    use HasFactory;
    protected $table = 'localidades';
    protected $primaryKey='id';
    protected $fillable=['descripcion','cp','id_tipo_localidad','id_municipio','id_ciudad','status'];
}
